package com.test.springboot.Model;

public class SupplyDemand {
	private String productId;
	private Double Availability;
	public String getProductId() {
		return productId;
	}
	public SupplyDemand(String productId) {
		super();
		this.productId = productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Double getAvailability() {
		return Availability;
	}
	public void setAvailability(Double availability) {
		Availability = availability;
	}
	public SupplyDemand(String productId, Double availability) {
		super();
		this.productId = productId;
		Availability = availability;
	}
	public SupplyDemand() {
		super();
	}

}
