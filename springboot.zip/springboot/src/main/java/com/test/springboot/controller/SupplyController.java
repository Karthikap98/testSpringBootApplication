package com.test.springboot.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.test.springboot.Model.Supply;

@RestController
public class SupplyController {
	
	@PostMapping("/updateSupply")
	public Supply getDatesByservice(@RequestBody Supply supply){
		
		LocalDateTime ldt = supply.getUpdateTimeStamp();
		LocalDate d =LocalDate.of(2021, 03, 16);
		
		List<Supply> supplyList = new ArrayList<>();
		supplyList.add(new Supply("Product1",LocalDateTime.of(d, LocalTime.of(8, 53, 48, 616)),10.0));
		supplyList.add(new Supply ("Product2",LocalDateTime.of(d, LocalTime.of(8, 59, 48, 616)),5.0));
		supplyList.add(new  Supply ("Product3",LocalDateTime.of(d, LocalTime.of(9, 10, 48, 616)),30.0));
		supplyList.add(new Supply ("Product4",LocalDateTime.of(d, LocalTime.of(9, 10, 48, 616)),20.0));
		
		for(Supply s : supplyList) {
			if(ldt.isBefore(s.getUpdateTimeStamp()) && supply.getProductId().equalsIgnoreCase(s.getProductId())){
				supply.setStatus("Out of Sync Update");
			}else if(ldt.isAfter(s.getUpdateTimeStamp()) && supply.getProductId().equalsIgnoreCase(s.getProductId())) {
				supply.setStatus("Updated");
				supply.setQuantity((s.getQuantity())+(supply.getQuantity()));
			}
		}
		return supply;
	}

}
