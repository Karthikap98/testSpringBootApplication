package com.test.springboot.service;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.test.springboot.Model.Order;
import com.test.springboot.Model.Shipment;

@Service
public class OrderShipmentService {

	 @Async
	public CompletableFuture<Order> getOrder(String orderId) {
		 Order o = new  Order ("Order1", "Prod1", 2.0);
		 List<Order> orderList = List.of(o);
		 return CompletableFuture
	                .completedFuture(orderList
	                        .stream()
	                        .filter(order -> order.getOrderId().equals(orderId)).iterator().next());

	}

	@Async
	public CompletableFuture<Shipment> getShipment(String orderId) {
		 Shipment s= new  Shipment ("Order1", "Ship1", "Prod1" ,LocalDate.of(2021, 02, 19), 2.0);
		 List<Shipment> shipmentList = List.of(s);
		 return CompletableFuture
	                .completedFuture(shipmentList
	                		.stream()
	                		.filter(shipment->shipment.getOrderId().equals(orderId)).iterator().next());
	   
	}

}
