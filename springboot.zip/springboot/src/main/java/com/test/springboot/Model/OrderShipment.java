package com.test.springboot.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderShipment {
	
     @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
     private String orderId;
	 public String getOrderId() {
	    return orderId;
	 }
	 private Order order;
	 private Shipment shipment;
     public Order getOrder() {
	    return order;
	}
	public Shipment getShipment() {
		return shipment;
	}
	public void setShipment(Shipment shipment) {
		this.shipment = shipment;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public OrderShipment(String orderId, Order order, Shipment shipment) {
		super();
		this.orderId = orderId;
		this.order = order;
		this.shipment = shipment;
	}
	public OrderShipment() {
		super();
	}
	public OrderShipment(String orderId) {
		super();
		this.orderId = orderId;
	}
    
	    

}
