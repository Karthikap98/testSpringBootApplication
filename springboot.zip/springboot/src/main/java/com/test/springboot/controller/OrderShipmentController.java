package com.test.springboot.controller;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.test.springboot.Model.Order;
import com.test.springboot.Model.OrderShipment;
import com.test.springboot.Model.Shipment;
import com.test.springboot.service.OrderShipmentService;

@RestController
public class OrderShipmentController {
	
	@Autowired
	OrderShipmentService orderShipmentService;
	
	@GetMapping("/getOrderDetails")
    public ResponseEntity<?> getOrder(@RequestBody OrderShipment orderShipment) throws ExecutionException, InterruptedException {

        CompletableFuture<Order> order = orderShipmentService.getOrder(orderShipment.getOrderId());
        CompletableFuture<Shipment> shipment = orderShipmentService.getShipment(orderShipment.getOrderId());

        OrderShipment orderShip=new OrderShipment();
        orderShip.setOrder(order.get());
        orderShip.setShipment(shipment.get());

        return ResponseEntity.ok(orderShip);
	}

}
