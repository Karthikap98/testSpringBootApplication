package com.test.springboot.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.test.springboot.Model.DemandPojo;
import com.test.springboot.Model.SupplyDemand;
import com.test.springboot.Model.SupplyPojo;

@RestController
public class SupplyDemandController {
	
	@PostMapping("/getAvailability")
	public ResponseEntity<?> getAvailability(@RequestBody SupplyDemand supplyDemand){
		
		List<SupplyPojo> supplyList = new ArrayList<>();
		supplyList.add(new SupplyPojo("Product1",10.0));
		supplyList.add(new SupplyPojo("Product2",5.0));
		
		List<DemandPojo> demandList = new ArrayList<>();
		demandList.add(new DemandPojo("Product1",2.0));
		demandList.add(new DemandPojo("Product2",5.0));
		
		Double supplyQuan = supplyList.stream()
				.filter(s->s.getProductId().equals(supplyDemand.getProductId()))
				.map(s->s.getQuantity()).iterator().next();
		Double demandQuan = demandList.stream()
				.filter(d->d.getProductId().equals(supplyDemand.getProductId()))
				.map(d->d.getQuantity()).iterator().next();
		
       Double quantity = supplyQuan-demandQuan;

       if(quantity==0) {
    	  return ResponseEntity.noContent().build();
       }else {
    	   supplyDemand.setAvailability(quantity);
    	   return ResponseEntity.ok(supplyDemand);
       }       
	}
}
